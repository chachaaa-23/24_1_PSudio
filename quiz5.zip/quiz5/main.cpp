#include "MyQueue.h"
#include <iostream>
#include <random>

/*
게임 몇판할지 입력
사용자의 가위바위보 입력, 결과를 queue에 넣기
랜덤으로 컴퓨터의 가위바위보 만들기
    1,2,3 숫자를 아까 위에서 입력한 만큼 만들게 한 뒤, 각 숫자를 가위바위보 알파벳으로 바꿔주기.
컴퓨터와의 결과를 dequeue하며 비교, 승리 비김 짐의 경우를 각각 변수에 넣기. 
결과 출력

이미 queue를 구현했고, 이를 넣기만 하면 된다.. ㅠㅠㅠㅠ
*/

int main() {
    MyQueue<int> myqueue(10);
    int count;

    return 0;
}